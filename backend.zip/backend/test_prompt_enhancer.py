from backend.prompt_enhancer import PromptEnhancer

enhancer = PromptEnhancer()

sample_params = {
    "mood": "energetic",
    "energy": 8,
    "style": "edm",
    "tempo": "fast",
    "instruments": ["synth", "drums"]
}

basic_prompt = "energetic EDM music"

enhanced_prompts = enhancer.enhance(sample_params, variations=3)

print("\nBASIC PROMPT:")
print(basic_prompt)

print("\nENHANCED PROMPTS:")
for i, p in enumerate(enhanced_prompts, 1):
    print(f"\nVariation {i}:")
    print(p)
